AI Finder — Netlify deployment

This archive contains the prebuilt production site. No build command is needed.

Publish a new site:
1. Sign in to Netlify.
2. Open https://app.netlify.com/drop
3. Drag and drop this ZIP (or an extracted copy of this folder).
4. Open the Netlify URL shown after the deploy finishes.

The archive is structured with index.html and the assets/ directory at its root, as Netlify expects for a prebuilt static site.
